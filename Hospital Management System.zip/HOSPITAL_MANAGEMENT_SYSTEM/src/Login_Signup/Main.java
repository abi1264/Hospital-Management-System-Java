package Login_Signup;

public class Main {
	public static void main(String[] args) {
		System.out.println("Hospital_Management_System");
		
		//Calling first page for login/signup buttons 
//		SignUp sign=new SignUp();
//		
		//calling login page
//		LoginPage page1=new LoginPage();
//		page1.LoginPagee();
		
		//calling Signup page
//		SignUpPage page2=new SignUpPage();
//		page2.SignUpPageMethod();
		
		//calling User Dashboard page
		UserDashBoard user1=new UserDashBoard();
		
		
		
	}

}
