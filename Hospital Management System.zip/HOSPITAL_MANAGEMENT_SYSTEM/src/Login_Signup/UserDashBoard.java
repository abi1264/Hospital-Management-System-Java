package Login_Signup;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class UserDashBoard extends JFrame {
	JLabel name,address,contact,age,email,gender;
	JPanel p1,p2,p3,p4,p5,p6;
	
	public UserDashBoard() {
		setTitle("User DashBoard");
		setSize(900,700);
		setLocation(300,40);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);
		
		//Top Panel
		JPanel head=new JPanel();
		JLabel title=new JLabel("USER INFORMATION");
		head.add(title);
		add(head);
		head.setBounds(350,10,200,50);
		
		//call methods
		GetName();
		GetAddress();
		GetContact();
		GetAge();
		GetGender();
		GetEmail();
		
		
	
		
		
		
		
		setVisible(true);
		
	}
	
	public void GetName() {
		
		p1=new JPanel();
		name=new JLabel("UserName : ");
		p1.add(name);
		add(p1);
		p1.setBounds(100,80,300,40);
		
	}
	
	public void GetAddress()
	{
		
		p2=new JPanel();
		address=new JLabel("Address : ");
		p2.add(address);
		add(p2);
		p2.setBounds(100,130,300,40);
		
	}
	
	public void GetContact() {
		p3=new JPanel();
		contact=new JLabel("Contact : ");
		p3.add(contact);
		add(p3);
		p3.setBounds(100,180,300,40);
			
	}
	
	public void GetAge() {
		p4=new JPanel();
		age=new JLabel("Age : ");
		p4.add(age);
		add(p4);
		p4.setBounds(100,230,300,40);
		
	}
	
	public void GetGender() {
		p5=new JPanel();
		gender=new JLabel("Gender : ");
		p5.add(gender);
		add(p5);
		p5.setBounds(100,280,300,40);
	}
	
	public void GetEmail() {
		p6=new JPanel();
		email=new JLabel("Email : ");
		p6.add(email);
		add(p6);
		p6.setBounds(100,330,300,40);
		
	}
	
	

}
