/**
 * 
 */
/**
 * 
 */
module HOSPITAL_MANAGEMENT_SYSTEM {
	requires java.desktop;
}